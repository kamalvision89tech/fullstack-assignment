const http = require('http');
const fs = require('fs');

const express = require('express');
const multer = require('multer');
const csv = require('fast-csv');

const Router = express.Router;
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'tmp/csv/')
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname+'.csv')
  }
})

var upload = multer({ storage: storage });
//const upload = multer({ dest: 'tmp/csv/test.csv' });
const app = express();
const router = new Router();
const server = http.createServer(app);
const port = 3000

app.post('/upload', upload.single('file'), function (req, res) {
  const fileRows = [];

  // // open uploaded file
  // csv.fromPath(req.file.path)
  //   .on("data", function (data) {
  //     fileRows.push(data); // push each row
  //   })
  //   .on("end", function () {
  //     //console.log(fileRows)
  //     const csv = require('csvtojson');
  //   function removeDuplicates(myArr, prop) {
  //       return myArr.filter((obj, pos, arr) => {
  //           return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
  //       });
  //   }
  //   function findDuplicates(myArr, prop) {
  //       return myArr.filter((obj, pos, arr) => {
  //           return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) != pos;
  //       });
  //   }

  //   function EndBalanceEmptyValidate(myArr, prop) {
  //       return myArr.filter((obj, pos, arr) => {
  //           return obj[prop] == "";
  //       });
  //   }
  //   csv().fromFile(req.file.path)
  //       .then((jsonObj) => {
  //           var report = {
  //               duplicateReferenceCount: findDuplicates(jsonObj, "Reference").length,
  //               duplicateReferenceList: findDuplicates(jsonObj, "Reference"),
  //               uniqueReferenceCount: removeDuplicates(jsonObj, "Reference").length,
  //               uniqueReferenceList: removeDuplicates(jsonObj, "Reference"),
  //               EndBalanceValidateCount: EndBalanceEmptyValidate(jsonObj, "End Balance").length,
  //               EndBalanceValidateList: EndBalanceEmptyValidate(jsonObj, "End Balance")
  //           }
  //           res.send(report);
  //       })
  //     //fs.unlinkSync(req.file.path);   // remove temp file
  //     //process "fileRows" and respond
  //   })
});

// Add headers
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.use('/upload-csv', router);


app.get('/CustomerStatement', function (req, res) {
    const csv = require('csvtojson');
    function removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    function findDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) != pos;
        });
    }

    function EndBalanceEmptyValidate(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return obj[prop] == "";
        });
    }
    csv().fromFile("./tmp/csv/file.csv")
        .then((jsonObj) => {
            var report = {
                duplicateReferenceCount: findDuplicates(jsonObj, "Reference").length,
                duplicateReferenceList: findDuplicates(jsonObj, "Reference"),
                uniqueReferenceCount: removeDuplicates(jsonObj, "Reference").length,
                uniqueReferenceList: removeDuplicates(jsonObj, "Reference"),
                EndBalanceValidateCount: EndBalanceEmptyValidate(jsonObj, "End Balance").length,
                EndBalanceValidateList: EndBalanceEmptyValidate(jsonObj, "End Balance")
            }
            res.send(report);
        })
    
});

// Start server
function startServer() {
  server.listen(port, function () {
    console.log('Express server listening on ', port);
  });
}

startServer();