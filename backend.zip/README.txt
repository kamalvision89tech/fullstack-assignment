Please make sure that nodejs(v6.11.2 or above) has installed in system:
----------------------------------------------------------------------
Steps to deploy:
----------------

1. Navigate ./assignment/backend/ folder
2. Open Cmd => run => npm run dev
3. Wait for some time to install all dependancies.
4. Open http://localhost:3000/CustomerStatement
5. Output Report for Records.CSV file is as follows format:

	   {
                duplicateReferenceCount: 'How many Refference Duplicates?',
                duplicateReferenceList: 'List of Refference Duplicated Items',
                uniqueReferenceCount: 'How many Refference Unique values',
                uniqueReferenceList: 'List of Refference Unique Items',
                EndBalanceValidateCount: 'How many End Balance contains empty strings?',
                EndBalanceValidateList: 'List of End Balance Empty Items',
            }

6. Check filter by count number value only.
