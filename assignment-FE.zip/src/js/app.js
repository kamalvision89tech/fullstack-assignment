var app = angular.module('app',[]);

app.controller('mainCntrl', ['$scope', '$http', 'CSV2JSONconvert', function ($scope, $http, CSV2JSONconvert){
    $scope.title = 'RABO Bank';
    $scope.issueListData = [];
    $scope.$watch('fileContent', function () {
        $scope.issueListData = JSON.parse(CSV2JSONconvert.CSV2JSON($scope.fileContent));
        console.log(CSV2JSONconvert.CSV2JSON($scope.fileContent));
    });
}]);

app.controller('backIntegCntrl', ['$scope', '$http', 'CSV2JSONconvert', function ($scope, $http, CSV2JSONconvert){

    $scope.recordsListData = [];
    $scope.uploadFile = function(files) {
        var fd = new FormData();
        //Take the first selected file
        fd.append("file", files[0]);

        $http.post('http://localhost:3000/upload', fd, {
            withCredentials: true,
            headers: {'Content-Type': undefined },
            transformRequest: angular.identity
        }).then(function(res){
            console.log(res);
        })

    };
    $http.get('http://localhost:3000/CustomerStatement', {}).then(function(res){
        $scope.recordsListData = res.data.duplicateReferenceList;
        $scope.duplicateReferenceCount = res.data.duplicateReferenceCount;
        $scope.uniqueReferenceCount = res.data.uniqueReferenceCount;
    });
}]);

app.factory('CSV2JSONconvert', function() {

    function CSVToArray(strData, strDelimiter) {
        strDelimiter = (strDelimiter || ",");
        var objPattern = new RegExp((
            "(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
            "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
            "([^\"\\" + strDelimiter + "\\r\\n]*))"), "gi");
        var arrData = [[]];
        var arrMatches = null;
        while (arrMatches = objPattern.exec(strData)) {
            var strMatchedDelimiter = arrMatches[1];
            if (strMatchedDelimiter.length && (strMatchedDelimiter != strDelimiter)) {
                arrData.push([]);
            }
            if (arrMatches[2]) {
                var strMatchedValue = arrMatches[2].replace(
                    new RegExp("\"\"", "g"), "\"");
            } else {
                var strMatchedValue = arrMatches[3];
            }
            arrData[arrData.length - 1].push(strMatchedValue);
        }
        return (arrData);
    }

    function CSV2JSON(csv) {
        var array = CSVToArray(csv);
        var objArray = [];
        for (var i = 1; i < array.length; i++) {
            objArray[i - 1] = {};
            for (var k = 0; k < array[0].length && k < array[i].length; k++) {
                var key = array[0][k];
                objArray[i - 1][key] = array[i][k]
            }
        }

        var json = JSON.stringify(objArray);
        var str = json.replace(/},/g, "},\r\n");

        return str;
    }
    return {
        'CSV2JSON': CSV2JSON,
        'CSVToArray': CSVToArray
    }
})

app.filter('matchAccessLevel', function () {
    return function (items, userAccessLevel) {
        var filtered = [];
        angular.forEach(items, function (item) {
            if (userAccessLevel == "" || userAccessLevel == null || userAccessLevel == undefined) {
                filtered = items;
            }
            if (userAccessLevel == item['Issue count']) {
                filtered.push(item);
            }
        });
        return filtered;
    };
});