var express = require('express');
var app = express();

app.get('/CustomerStatement', function (req, res) {
    const csv = require('csvtojson');
    function removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    function findDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) != pos;
        });
    }

    function EndBalanceEmptyValidate(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return obj[prop] == "";
        });
    }
    csv().fromFile("./src/records.csv")
        .then((jsonObj) => {
            var report = {
                duplicateReferenceCount: findDuplicates(jsonObj, "Reference").length,
                duplicateReferenceList: findDuplicates(jsonObj, "Reference"),
                uniqueReferenceCount: removeDuplicates(jsonObj, "Reference").length,
                uniqueReferenceList: removeDuplicates(jsonObj, "Reference"),
                EndBalanceValidateCount: EndBalanceEmptyValidate(jsonObj, "End Balance").length,
                EndBalanceValidateList: EndBalanceEmptyValidate(jsonObj, "End Balance")
            }
            res.send(report);
        })
    
});

app.listen(3000);